#!/bin/sh

# Runs the Present Company RPC compiler
java -jar ##PREFIX##/present-rpc-compiler.jar "$@"

